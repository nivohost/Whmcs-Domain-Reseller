<?php
namespace ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class GetNameServers extends Call
{
    public $action = "domains/:domain/nameservers";
    
    public $type = parent::TYPE_GET;
}