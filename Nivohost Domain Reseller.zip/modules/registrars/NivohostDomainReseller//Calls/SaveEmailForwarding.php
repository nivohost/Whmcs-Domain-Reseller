<?php
namespace ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class SaveEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_POST;
}