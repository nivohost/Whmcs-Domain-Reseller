<?php
namespace ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class Sync extends Call
{
    public $action = "domains/:domain/sync";
    
    public $type = parent::TYPE_POST;
}