<?php
namespace ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Core\Call;

/**
 * Description of CheckAvailability
 *
 * @author inbs
 */
class CheckAvailability extends Call
{
    public $action = "domains/lookup";
    
    public $type = parent::TYPE_POST;
}