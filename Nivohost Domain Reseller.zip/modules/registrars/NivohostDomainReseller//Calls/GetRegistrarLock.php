<?php
namespace ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\NivohostDomainReseller\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class GetRegistrarLock extends Call
{
    public $action = "domains/:domain/lock";
    
    public $type = parent::TYPE_GET;
}